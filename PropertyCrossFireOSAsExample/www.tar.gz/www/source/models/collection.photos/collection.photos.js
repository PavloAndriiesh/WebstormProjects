RAD.model('collection.photos', Backbone.Collection.extend({

}), true);