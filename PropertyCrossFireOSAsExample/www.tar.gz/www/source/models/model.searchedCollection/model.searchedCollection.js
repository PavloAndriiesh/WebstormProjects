RAD.model('model.searchedCollection', Backbone.Model.extend({

}), true);