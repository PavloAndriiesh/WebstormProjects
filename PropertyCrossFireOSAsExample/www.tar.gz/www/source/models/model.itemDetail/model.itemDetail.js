RAD.model('model.itemDetail', Backbone.Model.extend({

}), true);