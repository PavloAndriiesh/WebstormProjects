RAD.model('collection.searchedWords', Backbone.Collection.extend({

}), true);