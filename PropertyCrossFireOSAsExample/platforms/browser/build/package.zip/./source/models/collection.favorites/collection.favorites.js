RAD.model('collection.favorites', Backbone.Collection.extend({

}), true);