RAD.model('model.confirmLogout', Backbone.Model.extend({

}), true);