RAD.model('model.productDetails', Backbone.Model.extend({

}), true);