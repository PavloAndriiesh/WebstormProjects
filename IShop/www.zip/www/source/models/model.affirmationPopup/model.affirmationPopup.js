RAD.model('model.affirmationPopup', Backbone.Model.extend({

}), true);