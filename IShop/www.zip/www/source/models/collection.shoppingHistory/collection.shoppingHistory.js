RAD.model('collection.shoppingHistory', Backbone.Collection.extend({

}), true);