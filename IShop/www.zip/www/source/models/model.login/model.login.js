RAD.model('model.login', Backbone.Model.extend({

}), true);