RAD.model('collection.shoppingCart', Backbone.Collection.extend({

}), true);