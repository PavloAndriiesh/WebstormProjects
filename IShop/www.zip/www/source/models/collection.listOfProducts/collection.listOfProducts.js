RAD.model('collection.listOfProducts', Backbone.Collection.extend({

}), true);